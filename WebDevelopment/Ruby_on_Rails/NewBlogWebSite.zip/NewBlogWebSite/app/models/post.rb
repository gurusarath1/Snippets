class Post < ApplicationRecord
  SENTIMENT_LIST_ITEMS = ['Good', 'Bad', 'Awesome', 'Forget It']
end
