require 'test_helper'

class RootUserControllerTest < ActionDispatch::IntegrationTest
  test "should get settings" do
    get root_user_settings_url
    assert_response :success
  end

end
