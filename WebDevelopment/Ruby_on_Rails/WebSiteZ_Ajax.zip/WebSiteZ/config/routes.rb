Rails.application.routes.draw do
  resources :articles
  get 'root_user/settings'
  get 'root_user/toolTipConfig'
  get 'root_user/getToolTips'
  post 'root_user/updateToolTips'

  root to: 'portfolios#index'
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
