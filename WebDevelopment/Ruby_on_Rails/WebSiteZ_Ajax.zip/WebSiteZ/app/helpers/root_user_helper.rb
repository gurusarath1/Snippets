module RootUserHelper


  def get_TOOLTIP_text(articleTitle, toolTipName)
    fetchedTT = ToolTip.where(articleTitle: articleTitle ,toolTipName: toolTipName)
    puts 'FETCHED IN BACKEND = ' + fetchedTT.to_ary.to_s

    if fetchedTT.none?
      puts 'Tooltip NOT found'
      return 'DEFAULT TOOL TIP TEXT'
    else
      puts 'Tooltip found'
      tooltip_record = fetchedTT.to_ary.first
    end

    return tooltip_record.toolTipText
  end



end
