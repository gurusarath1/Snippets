class RootUserController < ApplicationController
  def settings
  end

  def get_TOOLTIP(articleTitle, toolTipName)
    fetchedTT = ToolTip.where(articleTitle: articleTitle ,toolTipName: toolTipName)
    puts 'FETCHED IN BACKEND = ' + fetchedTT.to_ary.to_s

    if fetchedTT.none?
      puts 'Tooltip NOT found'
      tooltip_record = ToolTip.new
      tooltip_record.toolTipText = "No ToolTip Found !!"
    else
      puts 'Tooltip found'
      tooltip_record = fetchedTT.to_ary.first
    end

    return tooltip_record
  end

  def toolTipConfig
    puts '************ TT ***************'

    @article_list = []
    @articles = Article.all

    @articles.each do |artcl|
      @article_list.push(artcl.title.to_s)
    end


  end

  def getToolTips
    puts '************ GET TT ***************'
    puts 'PARAMS IN BACKEND = ' + params.to_s
    puts 'ALL TOOL TIPS \n\n' + ToolTip.all.to_ary.to_s

    @TT = get_TOOLTIP(params[:article_tt], params[:tt])

    respond_to do |format|
      format.json  { render :json => @TT }
    end


  end

  def updateToolTips
    puts '************ UPDATE TT ***************'
    puts 'PARAMS IN BACKEND = ' + params.to_s
    puts 'ALL TOOL TIPS \n\n' + ToolTip.all.to_ary.to_s
    @fetchedTT = ToolTip.where(portfolioId: params[:article_tt] ,toolTipName: params[:tt])

    if @fetchedTT.none?
      puts 'Creating new Tool Tip ------------ '
      @TT = ToolTip.new
      @TT.articleTitle = params[:article_tt]
      @TT.toolTipName = params[:tt]
      @TT.toolTipText = params[:tt_text]
      @TT.save
    else
      puts 'Updating Tool Tip ------------ '
    end

  end

end
