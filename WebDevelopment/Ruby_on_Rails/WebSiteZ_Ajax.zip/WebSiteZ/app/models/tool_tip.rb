class ToolTip < ApplicationRecord
end
