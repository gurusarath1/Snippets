class AddTitleAndContentToPortfolio < ActiveRecord::Migration[6.0]
  def change
    add_column :portfolios, :title, :string
    add_column :portfolios, :content, :string
  end
end
