class AddArticleTitleToToolTips < ActiveRecord::Migration[6.0]
  def change
    add_column :tool_tips, :articleTitle, :string
  end
end
