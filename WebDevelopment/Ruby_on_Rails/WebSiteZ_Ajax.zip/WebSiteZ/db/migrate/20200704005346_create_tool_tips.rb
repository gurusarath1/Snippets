class CreateToolTips < ActiveRecord::Migration[6.0]
  def change
    create_table :tool_tips do |t|
      t.integer :portfolioId
      t.string :toolTipName
      t.string :toolTipText

      t.timestamps
    end
  end
end
